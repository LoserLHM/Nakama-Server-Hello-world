﻿using System.Collections;
using System.Collections.Generic;
using Nakama;
using Nakama.TinyJson;
using UnityEngine;
using UnityEngine.UI;


public class NakamaClient : MonoBehaviour
{
    private readonly IClient client = new Client("http","127.0.0.1",7350,"defaultkey");
    private ISession session;

    public Text txt_sayHelloWorld;
    public string str_payload_HelloWorld;
    async void Start()
    {
        /*connect and sync by email*/
        const string email = "plzSayHelloToMe@HelloWorld.com";
        const string password = "WhatEever";
        var session = await client.AuthenticateEmailAsync(email, password);
        Debug.Log(session);

        var payload_helloWorld = "{}"; // Empty variable waiting for the Hello World from Json
        var rpcid_HelloWorld = "SayHelloWorld_rpc_func_ID"; //The RPC function ID
        var custom_rpc_HelloWorld_funcinfo = await client.RpcAsync(session, rpcid_HelloWorld, payload_helloWorld); // Client's execution call
        Debug.LogFormat("custom_rpc_HelloWorld_funcinfo:{0}", custom_rpc_HelloWorld_funcinfo);
        str_payload_HelloWorld = custom_rpc_HelloWorld_funcinfo.Payload; //Stored as a string and ready to present
    }
    void Update()
    {
        txt_sayHelloWorld.text = str_payload_HelloWorld; //Present in unlity
    }

}
